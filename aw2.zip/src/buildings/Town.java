package buildings;

public class Town extends Base {

	public Town(int owner, int xx, int yy) {
		super(owner, xx, yy);
		name="Town";
		desc="Money Fodder.";
		img = 1;
	}
}
