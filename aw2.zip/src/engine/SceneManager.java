package engine;

public class SceneManager {
	//TODO: Handle all special effects and cut scenes.
	//This might get replaced with a vector<scene.Base> with a plug in the loop to handle its timings.
	//Only time will tell, dun dun dun!
}
