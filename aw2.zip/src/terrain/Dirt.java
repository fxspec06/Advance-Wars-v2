package terrain;

public class Dirt extends Base {
	public Dirt() {
		name = "Dirt";
	}
	public double speed() {return 1;}
	public double defense() {return 1;}
}
