This is an Advance Wars clone project's source code by Serge-David from www.blog.knolif.com

Currently all the features are being slowly hacked together in this early stage of development (pre-alpha).
Eventually I'll rework the code to hopefully work and look cleaner as I get to the end of adding things.
The purpose of putting up my source code for the public is to hopefully help others who wish to get into making games with java in some way or another.
This project is under the GNU GENERAL PUBLIC LICENSE, you should check out the License.txt file for more information about that.
For those of you that might use some of the code in this project, please send me a link (download / pictures / blog) so I can check out your project(s) as well.

I have several goals on what I want to do in this project.
	1) Custom Texture Packs: User created zip files placed in a directory that the game can extract sprite sheets to use if selected.
	2) Smarter User Interfaces: Such as the many menu's that find their ways around a game.
	3) Finish a game to the point that I can release it into the wild.
	4) Compact and smart way of handling map files that will handle custom units, cities, and terrain gracefully.
	5) The ability to change the windows size.
	6) Improve general coding style and handling.
	7) Attempt at including an at least usable AI.
	#) And more.
   
I'll add to this read-me and the rest more later, cya all and thank you for any support / encouragement you give me.
I don't only make games because I love them and love making them, but because I love people enjoying them and I hope someday I'll finish one that people play.